let minutes=prompt("Enter the no of minute(s)");
console.log(minutes+" minute(s) "+" = " + minutes*60+" seconds.");